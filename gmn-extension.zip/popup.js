/**
 * GMN Prospector v4 — Popup UI
 * Pure UI — polls chrome.storage.session every 800ms.
 * Collection runs in background.js; popup can be closed/reopened freely.
 */

'use strict';

// ─── Elements ─────────────────────────────────────────────────────────────────

const formSection    = document.querySelector('.form-section');
const loadingSection = document.getElementById('loading-section');
const resultsSection = document.getElementById('results-section');
const errorSection   = document.getElementById('error-section');

const queryInput  = document.getElementById('query');
const cidadeInput = document.getElementById('cidade');
const qtyInput    = document.getElementById('qty');
const btnSearch   = document.getElementById('btn-search');

const loadingText     = document.getElementById('loading-text');
const loadingSub      = document.getElementById('loading-sub');
const loadingProgress = document.getElementById('loading-progress');
const progressFill    = document.getElementById('progress-fill');
const progressLabel   = document.getElementById('progress-label');

const resultsCount   = document.getElementById('results-count');
const resultsQuery   = document.getElementById('results-query');
const sourceBadge    = document.getElementById('source-badge');
const resultsPreview = document.getElementById('results-preview');

const debugPanel  = document.getElementById('debug-panel');
const debugLog    = document.getElementById('debug-log');
const debugClose  = document.getElementById('debug-close');

const btnCsv          = document.getElementById('btn-csv');
const btnExcel        = document.getElementById('btn-excel');
const btnNew          = document.getElementById('btn-new');
const btnRetry        = document.getElementById('btn-retry');
const errorText       = document.getElementById('error-text');

// ─── Poll ─────────────────────────────────────────────────────────────────────

let pollInterval = null;

function startPolling() {
  if (pollInterval) return;
  pollInterval = setInterval(syncState, 800);
}

function stopPolling() {
  if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
}

async function syncState() {
  const { gmn } = await chrome.storage.session.get('gmn');
  if (!gmn) return;
  if (gmn.state === 'running') showLoading(gmn);
  else if (gmn.state === 'done')  { stopPolling(); showResults(gmn); }
  else if (gmn.state === 'error') { stopPolling(); showError(gmn.errorMessage || 'Erro desconhecido'); }
}

// ─── Sections ─────────────────────────────────────────────────────────────────

function hideAll() {
  formSection.style.display    = 'none';
  loadingSection.style.display = 'none';
  resultsSection.style.display = 'none';
  errorSection.style.display   = 'none';
}

function showForm() {
  hideAll();
  formSection.style.display = 'flex';
  stopPolling();
}

function showLoading(s) {
  hideAll();
  loadingSection.style.display = 'flex';
  const found  = s.found  || 0;
  const target = s.target || parseInt(qtyInput.value) || 20;
  const pct    = s.progress || Math.round((found / target) * 100) || 0;
  if (found > 0) {
    loadingText.textContent = 'Enriquecendo dados...';
    loadingSub.textContent  = `${found} de ${target} empresas processadas`;
    loadingProgress.style.display = 'flex';
    progressFill.style.width = pct + '%';
    progressLabel.textContent = `${found} / ${target}`;
  } else {
    loadingText.textContent = 'Buscando no Google Maps...';
    loadingSub.textContent  = 'Pode usar outras abas normalmente';
    loadingProgress.style.display = 'none';
  }
}

function showResults(s) {
  hideAll();
  resultsSection.style.display = 'flex';
  const results = s.results || [];
  window._gmnResults = results;
  window._gmnQuery   = s.query || 'leads';

  resultsCount.textContent = results.length;
  resultsQuery.textContent = s.query || '';

  const withPhone = results.filter(r => r.phone).length;
  const withSite  = results.filter(r => r.website).length;
  const pct = results.length > 0 ? Math.round(((withPhone + withSite) / (results.length * 2)) * 100) : 0;

  sourceBadge.textContent = `${pct}% enriquecidos`;
  sourceBadge.style.color = pct > 60 ? '#22c55e' : pct > 30 ? '#f59e0b' : '#7a8ab8';

  resultsPreview.innerHTML = '';
  results.slice(0, 5).forEach(r => {
    const card = document.createElement('div');
    card.className = 'preview-card';
    card.innerHTML = `
      <div class="preview-name">${esc(r.name)}</div>
      <div class="preview-meta">
        ${r.phone ? `<span class="preview-phone">📞 ${esc(r.phone)}</span>` : `<span class="preview-no-phone">Sem telefone</span>`}
        ${r.rating ? `<span class="preview-rating">⭐ ${r.rating}</span>` : ''}
      </div>
      ${r.address ? `<div class="preview-address">${esc(r.address)}</div>` : ''}
    `;
    resultsPreview.appendChild(card);
  });
  if (results.length > 5) {
    const more = document.createElement('div');
    more.className = 'preview-more';
    more.textContent = `+ ${results.length - 5} empresas no download`;
    resultsPreview.appendChild(more);
  }
}

function showError(msg) {
  hideAll();
  errorSection.style.display = 'flex';
  errorText.textContent = msg;
}

function esc(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Search ───────────────────────────────────────────────────────────────────

btnSearch.addEventListener('click', async () => {
  const query  = queryInput.value.trim();
  const cidade = cidadeInput.value.trim();
  const target = Math.max(1, Math.min(200, parseInt(qtyInput.value) || 20));

  if (!query) { queryInput.focus(); return; }

  await chrome.storage.session.set({
    gmn: { state: 'running', found: 0, results: [], target, query: cidade ? `${query} em ${cidade}` : query }
  });

  showLoading({ found: 0, target });
  chrome.runtime.sendMessage({ type: 'START_SEARCH', query, cidade, target });
  startPolling();
});

// Enforce qty bounds on blur
qtyInput.addEventListener('blur', () => {
  const v = parseInt(qtyInput.value);
  if (isNaN(v) || v < 1)  qtyInput.value = 1;
  if (v > 200)             qtyInput.value = 200;
});

// ─── Debug Panel ─────────────────────────────────────────────────────────────

const ICONS = { info: '›', ok: '✓', warn: '!', error: '✗' };

function renderLogs(logs) {
  debugLog.innerHTML = '';
  const start = logs[0]?.t || Date.now();
  logs.forEach(entry => {
    const el = document.createElement('div');
    el.className = `debug-entry level-${entry.level}`;
    const elapsed = ((entry.t - start) / 1000).toFixed(1);
    el.innerHTML = `<span class="debug-time">+${elapsed}s</span><span class="debug-icon">${ICONS[entry.level] || '·'}</span><span class="debug-msg">${esc(entry.msg)}${entry.data ? '\n  ' + esc(entry.data) : ''}</span>`;
    debugLog.appendChild(el);
  });
  debugLog.scrollTop = debugLog.scrollHeight;
}

async function openDebug() {
  const { gmnLogs } = await chrome.storage.session.get('gmnLogs');
  renderLogs(gmnLogs || []);
  debugPanel.style.display = 'flex';
}

function closeDebug() { debugPanel.style.display = 'none'; }

debugClose?.addEventListener('click', closeDebug);
document.getElementById('btn-debug-toggle')?.addEventListener('click', openDebug);
document.getElementById('btn-debug-results')?.addEventListener('click', openDebug);
document.getElementById('btn-debug-error')?.addEventListener('click', openDebug);

// Auto-refresh logs while panel is open
setInterval(async () => {
  if (debugPanel.style.display === 'none') return;
  const { gmnLogs } = await chrome.storage.session.get('gmnLogs');
  const logs = gmnLogs || [];
  if (logs.length !== debugLog.children.length) renderLogs(logs);
}, 900);

// ─── New / Retry ──────────────────────────────────────────────────────────────

btnNew?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CANCEL' });
  chrome.storage.session.remove('gmn');
  closeDebug();
  showForm();
});

btnRetry?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CANCEL' });
  chrome.storage.session.remove('gmn');
  closeDebug();
  showForm();
});

// ─── Export CSV ───────────────────────────────────────────────────────────────

btnCsv?.addEventListener('click', () => {
  const r = window._gmnResults;
  if (!r?.length) return;

  const headers = ['Nome','Telefone','Website','Endereço','Avaliação','Avaliações','Categoria','Latitude','Longitude','Place ID'];
  const rows = r.map(x => [
    x.name     || '',
    x.phone    || '',
    x.website  || '',
    x.address  || '',
    x.rating   != null ? x.rating   : '',
    x.reviews  != null ? x.reviews  : '',
    x.category || '',
    x.lat      != null ? x.lat      : '',
    x.lng      != null ? x.lng      : '',
    x.place_id || ''
  ]);

  const csv = '\uFEFF' + [headers, ...rows]
    .map(row => row.map(c => `"${String(c).replace(/"/g,'""')}"`).join(','))
    .join('\r\n');

  downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }),
    `leads_${slugify(window._gmnQuery)}.csv`);
});

// ─── Export XLSX ─────────────────────────────────────────────────────────────

btnExcel?.addEventListener('click', () => {
  const r = window._gmnResults;
  if (!r?.length) return;

  const headers = ['Nome','Telefone','Website','Endereço','Avaliação','Avaliações','Categoria','Latitude','Longitude','Place ID'];
  const rows = r.map(x => [
    x.name     || '',
    x.phone    || '',
    x.website  || '',
    x.address  || '',
    x.rating   != null ? x.rating   : '',
    x.reviews  != null ? x.reviews  : '',
    x.category || '',
    x.lat      != null ? x.lat      : '',
    x.lng      != null ? x.lng      : '',
    x.place_id || ''
  ]);

  downloadBlob(buildXlsx([headers, ...rows], 'Leads'),
    `leads_${slugify(window._gmnQuery)}.xlsx`);
});

// ─── XLSX Builder (pure JS — no deps) ────────────────────────────────────────

function buildXlsx(data, sheetName) {
  // Shared strings
  const strings = [];
  const stringMap = new Map();
  function si(s) {
    const k = String(s);
    if (!stringMap.has(k)) { stringMap.set(k, strings.length); strings.push(k); }
    return stringMap.get(k);
  }

  // Sheet
  let sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/sheet"
           xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetData>`;

  data.forEach((row, ri) => {
    sheetXml += `<row r="${ri + 1}">`;
    row.forEach((cell, ci) => {
      const ref = `${colLetter(ci)}${ri + 1}`;
      const v   = cell == null ? '' : cell;
      if (typeof v === 'number') {
        sheetXml += `<c r="${ref}"><v>${v}</v></c>`;
      } else {
        sheetXml += `<c r="${ref}" t="s"><v>${si(v)}</v></c>`;
      }
    });
    sheetXml += `</row>`;
  });
  sheetXml += `</sheetData></worksheet>`;

  // Shared strings
  let ssXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/sheet" count="${strings.length}" uniqueCount="${strings.length}">`;
  strings.forEach(s => { ssXml += `<si><t xml:space="preserve">${xesc(s)}</t></si>`; });
  ssXml += `</sst>`;

  // Styles (REQUIRED by Excel — minimal)
  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/sheet">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="2">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
  </fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>
</styleSheet>`;

  const wbXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/sheet"
          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="${xesc(sheetName)}" sheetId="1" r:id="rId1"/></sheets>
</workbook>`;

  const wbRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml"  ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml"          ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/sharedStrings.xml"     ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
  <Override PartName="/xl/styles.xml"            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;

  const pkgRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

  return zipFiles({
    '[Content_Types].xml':          contentTypes,
    '_rels/.rels':                  pkgRels,
    'xl/workbook.xml':              wbXml,
    'xl/_rels/workbook.xml.rels':   wbRels,
    'xl/worksheets/sheet1.xml':     sheetXml,
    'xl/sharedStrings.xml':         ssXml,
    'xl/styles.xml':                stylesXml
  });
}

function colLetter(idx) {
  let s = ''; idx++;
  while (idx > 0) { s = String.fromCharCode(64 + (idx - 1) % 26 + 1) + s; idx = Math.floor((idx - 1) / 26); }
  return s;
}

function xesc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                  .replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}

// ─── ZIP writer ───────────────────────────────────────────────────────────────

function zipFiles(files) {
  const enc = new TextEncoder();

  // Build CRC32 table
  const crcTbl = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    crcTbl[i] = c;
  }
  function crc32(data) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < data.length; i++) crc = crcTbl[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function u16(n) { return [(n) & 0xFF, (n >> 8) & 0xFF]; }
  function u32(n) { return [(n) & 0xFF, (n >> 8) & 0xFF, (n >> 16) & 0xFF, (n >> 24) & 0xFF]; }

  const localParts  = [];
  const centralParts = [];
  const meta = [];
  let offset = 0;

  for (const [name, content] of Object.entries(files)) {
    const nameBytes = enc.encode(name);
    const data      = enc.encode(content);
    const crc       = crc32(data);
    const size      = data.length;
    // DOS date: 2024-01-01 = (44<<9)|(1<<5)|1 = 0x5821; time=0
    const dosDate   = [...u16(0), ...u16(0x5821)];

    const lh = [
      0x50,0x4B,0x03,0x04,          // local file header sig
      ...u16(20),                    // version needed
      ...u16(0),                     // flags
      ...u16(0),                     // compression (stored)
      ...dosDate,                    // mod time, mod date
      ...u32(crc),
      ...u32(size),                  // compressed size
      ...u32(size),                  // uncompressed size
      ...u16(nameBytes.length),
      ...u16(0),                     // extra field length
      ...nameBytes
    ];

    meta.push({ nameBytes, crc, size, offset });
    localParts.push(...lh, ...data);
    offset += lh.length + size;

    centralParts.push(
      0x50,0x4B,0x01,0x02,
      ...u16(20), ...u16(20),       // version made by, version needed
      ...u16(0), ...u16(0),         // flags, compression
      ...dosDate,
      ...u32(crc),
      ...u32(size), ...u32(size),
      ...u16(nameBytes.length),
      ...u16(0), ...u16(0),         // extra, comment
      ...u16(0), ...u16(0),         // disk start, internal attrs
      ...u32(0),                    // external attrs
      ...u32(meta[meta.length - 1].offset),
      ...nameBytes
    );
  }

  const cdOffset = offset;
  const cdSize   = centralParts.length;
  const eocd = [
    0x50,0x4B,0x05,0x06,
    ...u16(0), ...u16(0),
    ...u16(meta.length), ...u16(meta.length),
    ...u32(cdSize), ...u32(cdOffset),
    ...u16(0)
  ];

  return new Blob([new Uint8Array([...localParts, ...centralParts, ...eocd])],
    { type: 'application/zip' });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement('a'), { href: url, download: filename });
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function slugify(str) {
  return (str || 'leads').toLowerCase()
    .replace(/[àáâãä]/g,'a').replace(/[èéêë]/g,'e').replace(/[ìíîï]/g,'i')
    .replace(/[òóôõö]/g,'o').replace(/[ùúûü]/g,'u').replace(/ç/g,'c')
    .replace(/[^a-z0-9]/g,'_').replace(/_+/g,'_').slice(0,40);
}

// ─── Init ─────────────────────────────────────────────────────────────────────

(async function init() {
  const { gmn } = await chrome.storage.session.get('gmn');
  if (!gmn || gmn.state === 'idle') { showForm(); return; }
  if (gmn.state === 'running') { showLoading(gmn); startPolling(); return; }
  if (gmn.state === 'done')    { showResults(gmn); return; }
  if (gmn.state === 'error')   { showError(gmn.errorMessage || 'Erro'); return; }
  showForm();
})();
