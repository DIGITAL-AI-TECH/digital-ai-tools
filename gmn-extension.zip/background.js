/**
 * GMN Prospector v5 — Background Service Worker
 *
 * ARCHITECTURE:
 * - Opens ONE Maps tab as INACTIVE (active:false) → popup stays open the whole time
 * - Phase 1: scroll search results, collect place_ids from DOM
 * - Phase 2: navigate that same tab to each place detail URL, extract from DOM
 *   → Real rendered DOM = phone, website, address, lat/lng are all there
 *   → No new tabs, no fetch-based parsing, no JSON-LD guessing
 */

'use strict';

let collectionAborted = false;

// ─── Logger ───────────────────────────────────────────────────────────────────

async function log(level, msg, data) {
  const entry = {
    t: Date.now(), level, msg,
    data: data !== undefined ? JSON.stringify(data).slice(0, 400) : undefined
  };
  const s = await chrome.storage.session.get('gmnLogs');
  const logs = s.gmnLogs || [];
  logs.push(entry);
  if (logs.length > 300) logs.splice(0, logs.length - 300);
  await chrome.storage.session.set({ gmnLogs: logs });
}

// ─── Messages ────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'START_SEARCH') {
    collectionAborted = false;
    runCollection(msg.query, msg.cidade, msg.target)
      .catch(err => setError(err.message || String(err)));
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CANCEL') {
    collectionAborted = true;
    sendResponse({ ok: true });
    return true;
  }
});

// ─── Storage ─────────────────────────────────────────────────────────────────

function setState(patch) {
  return chrome.storage.session.get('gmn').then(d =>
    chrome.storage.session.set({ gmn: { ...(d.gmn || {}), ...patch } })
  );
}

function setError(msg) {
  log('error', `ERRO: ${msg}`);
  return chrome.storage.session.set({ gmn: { state: 'error', errorMessage: msg } })
    .then(() => setBadge('!', '#ef4444'));
}

// ─── Badge ───────────────────────────────────────────────────────────────────

function setBadge(text, color) {
  chrome.action.setBadgeText({ text: String(text) });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}

// ─── Tab helpers ─────────────────────────────────────────────────────────────

function openTab(url) {
  // active: false → tab opens in background, popup stays open!
  return chrome.tabs.create({ url, active: false });
}

function closeTab(tabId) {
  return chrome.tabs.remove(tabId).catch(() => {});
}

function navigateTab(tabId, url) {
  return chrome.tabs.update(tabId, { url });
}

function waitForTabComplete(tabId, timeout = 20000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, timeout);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function injectScript(tabId, func, args = []) {
  return chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func,
    args
  }).then(res => res?.[0]?.result).catch(() => null);
}

// ─── Injected: wait for Maps search result cards ─────────────────────────────

function injected_waitForCards(timeoutMs) {
  return new Promise(resolve => {
    const end = Date.now() + timeoutMs;
    (function check() {
      if (document.querySelectorAll('[role="article"]').length > 0) return resolve(true);
      if (Date.now() > end) return resolve(false);
      setTimeout(check, 500);
    })();
  });
}

// ─── Injected: extract list cards (placeId + partial info) ───────────────────

function injected_extractListCards() {
  const seen = new Set();
  const cards = [];

  document.querySelectorAll('[role="article"]').forEach(card => {
    // Find place_id in any anchor href
    let placeId = null;
    for (const a of card.querySelectorAll('a[href]')) {
      const m1 = a.href.match(/place_id:([A-Za-z0-9_-]+)/);
      if (m1) { placeId = m1[1]; break; }
      const m2 = a.href.match(/(ChIJ[A-Za-z0-9_-]{8,50})/);
      if (m2) { placeId = m2[1]; break; }
    }
    // Fallback: scan innerHTML
    if (!placeId) {
      const m = card.innerHTML.match(/(ChIJ[A-Za-z0-9_-]{8,50})/);
      if (m) placeId = m[1];
    }
    if (!placeId || seen.has(placeId)) return;
    seen.add(placeId);

    const nameEl = card.querySelector('[class*="fontHeadlineSmall"], .qBF1Pd, h3, [aria-label]');
    const name = nameEl?.textContent?.trim() || card.getAttribute('aria-label') || '';

    const rEl = card.querySelector('[aria-label*="stars"], [aria-label*="estrelas"]');
    const rm = (rEl?.getAttribute('aria-label') || '').match(/(\d[.,]\d)/);
    const rating = rm ? parseFloat(rm[1].replace(',', '.')) : null;

    cards.push({ placeId, name, rating });
  });
  return cards;
}

// ─── Injected: scroll the results feed ───────────────────────────────────────

function injected_scrollPanel() {
  const feed = document.querySelector('[role="feed"]');
  if (feed) { feed.scrollBy(0, 900); return true; }
  const divs = Array.from(document.querySelectorAll('div')).filter(el => {
    const s = window.getComputedStyle(el);
    return (s.overflowY === 'scroll' || s.overflowY === 'auto') &&
      el.scrollHeight > el.clientHeight + 100 && el.clientHeight > 200;
  });
  if (divs.length) {
    divs.sort((a, b) => b.scrollHeight - a.scrollHeight)[0].scrollBy(0, 900);
    return true;
  }
  return false;
}

// ─── Injected: wait for place detail panel ───────────────────────────────────

function injected_waitForPlacePanel(timeoutMs) {
  return new Promise(resolve => {
    const end = Date.now() + timeoutMs;
    (function check() {
      // Most reliable signals that the place panel is loaded
      if (document.querySelector('[data-item-id^="phone:tel:"]')) return resolve('phone');
      if (document.querySelector('a[data-item-id="authority"]'))  return resolve('website');
      if (document.querySelector('h1.DUwDvf, h1[class*="DUwDvf"]')) return resolve('h1');
      if (document.querySelector('[data-item-id="address"]'))     return resolve('address');
      if (Date.now() > end) return resolve(null);
      setTimeout(check, 400);
    })();
  });
}

// ─── Injected: extract full place details from the rendered detail page DOM ───

function injected_extractPlaceDetails() {
  // Name
  const name = document.querySelector('h1.DUwDvf, h1[class*="DUwDvf"]')?.textContent?.trim()
             || document.querySelector('h1')?.textContent?.trim()
             || null;

  // Phone — Google Maps encodes it in data-item-id="phone:tel:+55..."
  const phoneEl = document.querySelector('[data-item-id^="phone:tel:"]');
  const phone = phoneEl?.dataset?.itemId?.replace('phone:tel:', '') || null;

  // Website — stable selector, anchor with data-item-id="authority"
  const siteEl = document.querySelector('a[data-item-id="authority"]');
  let website = siteEl?.href || null;
  if (website && (website.includes('google.com') || website.includes('goo.gl') || website.includes('maps.app'))) {
    website = null;
  }

  // Address
  const addrEl = document.querySelector(
    '[data-item-id="address"], [data-tooltip="Copy address"], [aria-label*="Address"], button[aria-label*="ndereço"]'
  );
  const address = addrEl?.querySelector('.Io6YTe, .rogA2c, [class*="fontBodyMedium"]')?.textContent?.trim()
               || addrEl?.textContent?.trim()?.split('\n')[0]?.trim()
               || null;

  // Rating + reviews — look in .F7nice block
  let rating = null, reviews = null;
  const rBlock = document.querySelector('.F7nice, [class*="F7nice"]');
  if (rBlock) {
    const rText = rBlock.querySelector('[aria-hidden="true"]')?.textContent?.trim();
    if (rText) rating = parseFloat(rText.replace(',', '.'));
    const revText = rBlock.querySelector('button span, [aria-label*="review"] span')
                  ?.textContent?.replace(/[^0-9]/g, '');
    if (revText) reviews = parseInt(revText) || null;
  }
  if (!rating) {
    const rl = document.querySelector('[aria-label*="stars"], [aria-label*="estrelas"]');
    const m = rl?.getAttribute('aria-label')?.match(/(\d[.,]\d)/);
    if (m) rating = parseFloat(m[1].replace(',', '.'));
  }

  // Category
  const category = document.querySelector('.DkEaL, button[jsaction*="category"] .Io6YTe')
                 ?.textContent?.trim() || null;

  // Coordinates from current page URL — /@lat,lng,zoom/
  const cm = location.href.match(/@(-?\d+\.\d{4,}),(-?\d+\.\d{4,})/);
  const lat = cm ? parseFloat(cm[1]) : null;
  const lng = cm ? parseFloat(cm[2]) : null;

  return { name, phone, website, address, rating, reviews, lat, lng, category };
}

// ─── Main collection ──────────────────────────────────────────────────────────

async function runCollection(query, cidade, target) {
  const searchQuery = cidade ? `${query} em ${cidade}` : query;
  const searchUrl   = `https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`;

  await chrome.storage.session.set({ gmnLogs: [] });
  await log('info', `Iniciando: "${searchQuery}"`, { target });
  await chrome.storage.session.set({
    gmn: { state: 'running', query: searchQuery, target, found: 0, results: [], startedAt: Date.now() }
  });
  setBadge('...', '#2D52EF');

  // ── Phase 1: Open search tab INACTIVE → popup stays open ──────────────────
  await log('info', 'Abrindo Google Maps em segundo plano (popup continua aberto)...');
  const tab = await openTab(searchUrl); // active: false
  await waitForTabComplete(tab.id, 25000);
  await sleep(3500); // extra wait for Maps SPA to hydrate

  const hasCards = await injectScript(tab.id, injected_waitForCards, [20000]);
  if (!hasCards && !collectionAborted) {
    await closeTab(tab.id);
    return setError('Google Maps não carregou resultados. Verifique conexão e tente novamente.');
  }
  if (collectionAborted) { await closeTab(tab.id); return; }
  await log('ok', 'Resultados do Maps carregados ✓');

  // ── Phase 2: Scroll and collect all place_ids + partial data ──────────────
  const seen = new Set();
  const placeIds = [];
  const partial  = {};
  const maxScrolls = Math.ceil(target / 5) + 10;

  await log('info', `Coletando places (meta: ${target}, até ${maxScrolls} scrolls)...`);

  for (let s = 0; placeIds.length < target && s < maxScrolls && !collectionAborted; s++) {
    const cards = await injectScript(tab.id, injected_extractListCards) || [];
    for (const c of cards) {
      if (c.placeId && !seen.has(c.placeId)) {
        seen.add(c.placeId);
        placeIds.push(c.placeId);
        partial[c.placeId] = c;
      }
    }
    await log('info', `Scroll ${s + 1}: ${placeIds.length} lugares únicos`);
    if (placeIds.length >= target) break;
    await injectScript(tab.id, injected_scrollPanel);
    await sleep(1400);
  }

  if (collectionAborted) { await closeTab(tab.id); return; }

  if (placeIds.length === 0) {
    await closeTab(tab.id);
    return setError('Nenhum resultado encontrado. Tente outros termos ou cidade.');
  }

  const toProcess = placeIds.slice(0, target);
  await log('ok', `${placeIds.length} places coletados — extraindo detalhes de ${toProcess.length}...`);

  // ── Phase 3: Navigate to each place, extract from rendered DOM ───────────
  const results = [];

  for (let i = 0; i < toProcess.length && !collectionAborted; i++) {
    const placeId = toProcess[i];
    const p = partial[placeId] || {};
    const label = p.name?.slice(0, 35) || placeId.slice(0, 14);

    await log('info', `[${i + 1}/${toProcess.length}] ${label}`);

    // Navigate the tab to that specific place
    await navigateTab(tab.id, `https://www.google.com/maps/search/?q=place_id:${placeId}&hl=pt-BR`);
    await waitForTabComplete(tab.id, 15000);
    await sleep(2000);

    // Wait for details panel to render
    const panelReady = await injectScript(tab.id, injected_waitForPlacePanel, [10000]);

    if (panelReady) {
      const details = await injectScript(tab.id, injected_extractPlaceDetails);
      if (details && (details.name || p.name)) {
        const record = {
          place_id: placeId,
          name:     details.name     || p.name    || null,
          phone:    details.phone    || null,
          website:  details.website  || null,
          address:  details.address  || null,
          rating:   details.rating   ?? p.rating  ?? null,
          reviews:  details.reviews  || null,
          lat:      details.lat      || null,
          lng:      details.lng      || null,
          category: details.category || null,
        };
        results.push(record);
        const tel  = record.phone   ? '✓' : '✗';
        const site = record.website ? '✓' : '✗';
        await log(
          record.phone || record.website ? 'ok' : 'warn',
          `${(record.name || '').slice(0, 38)} | tel=${tel} site=${site}`
        );
      } else {
        await log('warn', `Sem dados para ${label}`);
      }
    } else {
      await log('warn', `Timeout no painel de "${label}" — usando dados parciais`);
      // Save at least the partial data from the list
      if (p.name) {
        results.push({
          place_id: placeId,
          name: p.name, phone: null, website: null,
          address: null, rating: p.rating || null,
          reviews: null, lat: null, lng: null, category: null,
        });
      }
    }

    const pct = Math.round((i + 1) / toProcess.length * 100);
    await setState({ found: results.length, results: [...results], progress: pct });
    setBadge(String(results.length), '#2D52EF');
  }

  await closeTab(tab.id);
  if (collectionAborted) return;

  const withPhone = results.filter(r => r.phone).length;
  const withSite  = results.filter(r => r.website).length;
  await log('ok', `✅ ${results.length} leads | ${withPhone} com tel | ${withSite} com site`);

  await chrome.storage.session.set({
    gmn: { state: 'done', query: searchQuery, target, found: results.length, results }
  });
  setBadge('✓', '#22c55e');
}
