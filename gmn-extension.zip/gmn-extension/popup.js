/**
 * GMN Prospector v6 — Popup UI
 * Pure UI — polls chrome.storage.session every 800ms.
 * Collection runs in background.js; popup can be closed/reopened freely.
 */

'use strict';

// ─── Elements ─────────────────────────────────────────────────────────────────

const formSection    = document.querySelector('.form-section');
const loadingSection = document.getElementById('loading-section');
const resultsSection = document.getElementById('results-section');
const errorSection   = document.getElementById('error-section');

const queryInput  = document.getElementById('query');
const cidadeInput = document.getElementById('cidade');
const qtyInput    = document.getElementById('qty');
const btnSearch   = document.getElementById('btn-search');

const loadingText     = document.getElementById('loading-text');
const loadingSub      = document.getElementById('loading-sub');
const loadingProgress = document.getElementById('loading-progress');
const progressFill    = document.getElementById('progress-fill');
const progressLabel   = document.getElementById('progress-label');

const resultsCount   = document.getElementById('results-count');
const resultsQuery   = document.getElementById('results-query');
const sourceBadge    = document.getElementById('source-badge');
const resultsPreview = document.getElementById('results-preview');

const debugPanel  = document.getElementById('debug-panel');
const debugLog    = document.getElementById('debug-log');
const debugClose  = document.getElementById('debug-close');

const btnCsv          = document.getElementById('btn-csv');
const btnExcel        = document.getElementById('btn-excel');
const btnNew          = document.getElementById('btn-new');
const btnRetry        = document.getElementById('btn-retry');
const errorText       = document.getElementById('error-text');

// ─── Poll ─────────────────────────────────────────────────────────────────────

let pollInterval = null;

function startPolling() {
  if (pollInterval) return;
  pollInterval = setInterval(syncState, 800);
}

function stopPolling() {
  if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
}

async function syncState() {
  const { gmn } = await chrome.storage.session.get('gmn');
  if (!gmn) return;
  if (gmn.state === 'running') showLoading(gmn);
  else if (gmn.state === 'done')  { stopPolling(); showResults(gmn); }
  else if (gmn.state === 'error') { stopPolling(); showError(gmn.errorMessage || 'Erro desconhecido'); }
}

// ─── Sections ─────────────────────────────────────────────────────────────────

function hideAll() {
  formSection.style.display    = 'none';
  loadingSection.style.display = 'none';
  resultsSection.style.display = 'none';
  errorSection.style.display   = 'none';
}

function showForm() {
  hideAll();
  formSection.style.display = 'flex';
  stopPolling();
}

function showLoading(s) {
  hideAll();
  loadingSection.style.display = 'flex';
  const found  = s.found  || 0;
  const target = s.target || parseInt(qtyInput.value) || 20;
  const pct    = s.progress || Math.round((found / target) * 100) || 0;
  if (found > 0) {
    loadingText.textContent = 'Enriquecendo dados...';
    loadingSub.textContent  = `${found} de ${target} empresas processadas`;
    loadingProgress.style.display = 'flex';
    progressFill.style.width = pct + '%';
    progressLabel.textContent = `${found} / ${target}`;
  } else {
    loadingText.textContent = 'Buscando no Google Maps...';
    loadingSub.textContent  = 'Pode usar outras abas normalmente';
    loadingProgress.style.display = 'none';
  }
}

function showResults(s) {
  hideAll();
  resultsSection.style.display = 'flex';
  const results = s.results || [];
  window._gmnResults = results;
  window._gmnQuery   = s.query || 'leads';

  resultsCount.textContent = results.length;
  resultsQuery.textContent = s.query || '';

  const withPhone = results.filter(r => r.phone).length;
  const withSite  = results.filter(r => r.website).length;
  const pct = results.length > 0 ? Math.round(((withPhone + withSite) / (results.length * 2)) * 100) : 0;

  sourceBadge.textContent = `${pct}% enriquecidos`;
  sourceBadge.style.color = pct > 60 ? '#22c55e' : pct > 30 ? '#f59e0b' : '#7a8ab8';

  resultsPreview.innerHTML = '';
  results.slice(0, 5).forEach(r => {
    const card = document.createElement('div');
    card.className = 'preview-card';
    card.innerHTML = `
      <div class="preview-name">${esc(r.name)}</div>
      <div class="preview-meta">
        ${r.phone ? `<span class="preview-phone">📞 ${esc(r.phone)}</span>` : `<span class="preview-no-phone">Sem telefone</span>`}
        ${r.rating ? `<span class="preview-rating">⭐ ${r.rating}</span>` : ''}
      </div>
      ${r.address ? `<div class="preview-address">${esc(r.address)}</div>` : ''}
    `;
    resultsPreview.appendChild(card);
  });
  if (results.length > 5) {
    const more = document.createElement('div');
    more.className = 'preview-more';
    more.textContent = `+ ${results.length - 5} empresas no download`;
    resultsPreview.appendChild(more);
  }
}

function showError(msg) {
  hideAll();
  errorSection.style.display = 'flex';
  errorText.textContent = msg;
}

function esc(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Search ───────────────────────────────────────────────────────────────────

btnSearch.addEventListener('click', async () => {
  const query  = queryInput.value.trim();
  const cidade = cidadeInput.value.trim();
  const target = Math.max(1, Math.min(200, parseInt(qtyInput.value) || 20));

  if (!query) { queryInput.focus(); return; }

  await chrome.storage.session.set({
    gmn: { state: 'running', found: 0, results: [], target, query: cidade ? `${query} em ${cidade}` : query }
  });

  showLoading({ found: 0, target });
  chrome.runtime.sendMessage({ type: 'START_SEARCH', query, cidade, target });
  startPolling();
});

// Enforce qty bounds on blur
qtyInput.addEventListener('blur', () => {
  const v = parseInt(qtyInput.value);
  if (isNaN(v) || v < 1)  qtyInput.value = 1;
  if (v > 200)             qtyInput.value = 200;
});

// ─── Debug Panel ─────────────────────────────────────────────────────────────

const ICONS = { info: '›', ok: '✓', warn: '!', error: '✗' };

function renderLogs(logs) {
  debugLog.innerHTML = '';
  const start = logs[0]?.t || Date.now();
  logs.forEach(entry => {
    const el = document.createElement('div');
    el.className = `debug-entry level-${entry.level}`;
    const elapsed = ((entry.t - start) / 1000).toFixed(1);
    el.innerHTML = `<span class="debug-time">+${elapsed}s</span><span class="debug-icon">${ICONS[entry.level] || '·'}</span><span class="debug-msg">${esc(entry.msg)}${entry.data ? '\n  ' + esc(entry.data) : ''}</span>`;
    debugLog.appendChild(el);
  });
  debugLog.scrollTop = debugLog.scrollHeight;
}

async function openDebug() {
  const { gmnLogs } = await chrome.storage.session.get('gmnLogs');
  renderLogs(gmnLogs || []);
  debugPanel.style.display = 'flex';
}

function closeDebug() { debugPanel.style.display = 'none'; }

debugClose?.addEventListener('click', closeDebug);
document.getElementById('btn-debug-toggle')?.addEventListener('click', openDebug);
document.getElementById('btn-debug-results')?.addEventListener('click', openDebug);
document.getElementById('btn-debug-error')?.addEventListener('click', openDebug);

// Auto-refresh logs while panel is open
setInterval(async () => {
  if (debugPanel.style.display === 'none') return;
  const { gmnLogs } = await chrome.storage.session.get('gmnLogs');
  const logs = gmnLogs || [];
  if (logs.length !== debugLog.children.length) renderLogs(logs);
}, 900);

// ─── New / Retry ──────────────────────────────────────────────────────────────

btnNew?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CANCEL' });
  chrome.storage.session.remove('gmn');
  closeDebug();
  showForm();
});

btnRetry?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CANCEL' });
  chrome.storage.session.remove('gmn');
  closeDebug();
  showForm();
});

// ─── Shared column definition ─────────────────────────────────────────────────

function buildRows(r) {
  const headers = [
    'Nome','Telefone','WhatsApp','Website','Email',
    'Endereço','CEP','Bairro','Cidade','Estado',
    'Instagram','Facebook',
    'Avaliação','Avaliações','Categoria','Preço',
    'Horário','Latitude','Longitude','URL Maps','Place ID'
  ];
  const rows = r.map(x => [
    x.name               || '',
    x.phone              || '',
    x.whatsapp           || '',
    x.website            || '',
    x.email              || '',
    x.address            || '',
    x.cep                || '',
    x.bairro             || '',
    x.cidade             || '',
    x.estado             || '',
    x.instagram          || '',
    x.facebook           || '',
    x.rating   != null   ? x.rating   : '',
    x.reviews  != null   ? x.reviews  : '',
    x.category           || '',
    x.priceLevel         || '',
    x.horasFuncionamento || '',
    x.lat      != null   ? x.lat      : '',
    x.lng      != null   ? x.lng      : '',
    x.mapsUrl            || '',
    x.place_id           || ''
  ]);
  return { headers, rows };
}

// ─── Export CSV ───────────────────────────────────────────────────────────────

btnCsv?.addEventListener('click', async () => {
  const r = window._gmnResults;
  if (!r?.length) return;

  const { headers, rows } = buildRows(r);
  const csv = '\uFEFF' + [headers, ...rows]
    .map(row => row.map(c => `"${String(c).replace(/"/g,'""')}"`).join(','))
    .join('\r\n');

  await downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }),
    `leads_${slugify(window._gmnQuery)}.csv`);
});

// ─── Export Excel ─────────────────────────────────────────────────────────────
// Uses SpreadsheetML (Excel 2003 XML) — pure text, no binary ZIP.
// Excel, LibreOffice e Google Sheets abrem nativamente.

btnExcel?.addEventListener('click', async () => {
  const r = window._gmnResults;
  if (!r?.length) return;

  const { headers, rows } = buildRows(r);
  await downloadBlob(buildSpreadsheetML([headers, ...rows], 'Leads'),
    `leads_${slugify(window._gmnQuery)}.xls`);
});

// ─── SpreadsheetML Builder ────────────────────────────────────────────────────

function buildSpreadsheetML(data, sheetName) {
  function xe(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, ''); // strip invalid XML control chars
  }

  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xml += `<?mso-application progid="Excel.Sheet"?>\n`;
  xml += `<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"\n`;
  xml += ` xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n`;
  xml += ` <Styles>\n`;
  xml += `  <Style ss:ID="h"><Font ss:Bold="1"/></Style>\n`;
  xml += ` </Styles>\n`;
  xml += ` <Worksheet ss:Name="${xe(sheetName)}">\n`;
  xml += `  <Table>\n`;

  data.forEach((row, ri) => {
    const isHeader = ri === 0;
    xml += `   <Row>\n`;
    row.forEach(cell => {
      const v = cell == null ? '' : cell;
      const type = typeof v === 'number' && !isNaN(v) ? 'Number' : 'String';
      const style = isHeader ? ` ss:StyleID="h"` : '';
      xml += `    <Cell${style}><Data ss:Type="${type}">${type === 'Number' ? v : xe(String(v))}</Data></Cell>\n`;
    });
    xml += `   </Row>\n`;
  });

  xml += `  </Table>\n`;
  xml += ` </Worksheet>\n`;
  xml += `</Workbook>`;

  return new Blob(['\uFEFF' + xml], { type: 'application/vnd.ms-excel;charset=UTF-8' });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function downloadBlob(blob, filename) {
  // Use FileReader to convert blob → data URL, then chrome.downloads (MV3 safe)
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
  try {
    await chrome.downloads.download({ url: dataUrl, filename, saveAs: false });
  } catch (e) {
    // Fallback: anchor click
    const a = Object.assign(document.createElement('a'), { href: dataUrl, download: filename });
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

function slugify(str) {
  return (str || 'leads').toLowerCase()
    .replace(/[àáâãä]/g,'a').replace(/[èéêë]/g,'e').replace(/[ìíîï]/g,'i')
    .replace(/[òóôõö]/g,'o').replace(/[ùúûü]/g,'u').replace(/ç/g,'c')
    .replace(/[^a-z0-9]/g,'_').replace(/_+/g,'_').slice(0,40);
}

// ─── Init ─────────────────────────────────────────────────────────────────────

(async function init() {
  const { gmn } = await chrome.storage.session.get('gmn');
  if (!gmn || gmn.state === 'idle') { showForm(); return; }
  if (gmn.state === 'running') { showLoading(gmn); startPolling(); return; }
  if (gmn.state === 'done')    { showResults(gmn); return; }
  if (gmn.state === 'error')   { showError(gmn.errorMessage || 'Erro'); return; }
  showForm();
})();
