/**
 * GMN Prospector v6 — Popup UI
 * Pure UI — polls chrome.storage.session every 800ms.
 * Collection runs in background.js; popup can be closed/reopened freely.
 */

'use strict';

// ─── Elements ─────────────────────────────────────────────────────────────────

const formSection    = document.querySelector('.form-section');
const loadingSection = document.getElementById('loading-section');
const resultsSection = document.getElementById('results-section');
const errorSection   = document.getElementById('error-section');

const queryInput  = document.getElementById('query');
const cidadeInput = document.getElementById('cidade');
const qtyInput    = document.getElementById('qty');
const btnSearch   = document.getElementById('btn-search');

const loadingText     = document.getElementById('loading-text');
const loadingSub      = document.getElementById('loading-sub');
const loadingProgress = document.getElementById('loading-progress');
const progressFill    = document.getElementById('progress-fill');
const progressLabel   = document.getElementById('progress-label');

const resultsCount   = document.getElementById('results-count');
const resultsQuery   = document.getElementById('results-query');
const sourceBadge    = document.getElementById('source-badge');
const resultsPreview = document.getElementById('results-preview');

const debugPanel  = document.getElementById('debug-panel');
const debugLog    = document.getElementById('debug-log');
const debugClose  = document.getElementById('debug-close');

const btnCsv          = document.getElementById('btn-csv');
const btnExcel        = document.getElementById('btn-excel');
const btnNew          = document.getElementById('btn-new');
const btnRetry        = document.getElementById('btn-retry');
const errorText       = document.getElementById('error-text');

// ─── Poll ─────────────────────────────────────────────────────────────────────

let pollInterval = null;

function startPolling() {
  if (pollInterval) return;
  pollInterval = setInterval(syncState, 800);
}

function stopPolling() {
  if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
}

async function syncState() {
  const { gmn } = await chrome.storage.session.get('gmn');
  if (!gmn) return;
  if (gmn.state === 'running') showLoading(gmn);
  else if (gmn.state === 'done')  { stopPolling(); showResults(gmn); }
  else if (gmn.state === 'error') { stopPolling(); showError(gmn.errorMessage || 'Erro desconhecido'); }
}

// ─── Sections ─────────────────────────────────────────────────────────────────

function hideAll() {
  formSection.style.display    = 'none';
  loadingSection.style.display = 'none';
  resultsSection.style.display = 'none';
  errorSection.style.display   = 'none';
}

function showForm() {
  hideAll();
  formSection.style.display = 'flex';
  stopPolling();
}

function showLoading(s) {
  hideAll();
  loadingSection.style.display = 'flex';
  const found  = s.found  || 0;
  const target = s.target || parseInt(qtyInput.value) || 20;
  const pct    = s.progress || Math.round((found / target) * 100) || 0;
  if (found > 0) {
    loadingText.textContent = 'Enriquecendo dados...';
    loadingSub.textContent  = `${found} de ${target} empresas processadas`;
    loadingProgress.style.display = 'flex';
    progressFill.style.width = pct + '%';
    progressLabel.textContent = `${found} / ${target}`;
  } else {
    loadingText.textContent = 'Buscando no Google Maps...';
    loadingSub.textContent  = 'Pode usar outras abas normalmente';
    loadingProgress.style.display = 'none';
  }
}

function showResults(s) {
  hideAll();
  resultsSection.style.display = 'flex';
  const results = s.results || [];
  window._gmnResults = results;
  window._gmnQuery   = s.query || 'leads';

  resultsCount.textContent = results.length;
  resultsQuery.textContent = s.query || '';

  const withPhone = results.filter(r => r.phone).length;
  const withSite  = results.filter(r => r.website).length;
  const pct = results.length > 0 ? Math.round(((withPhone + withSite) / (results.length * 2)) * 100) : 0;

  sourceBadge.textContent = `${pct}% enriquecidos`;
  sourceBadge.style.color = pct > 60 ? '#22c55e' : pct > 30 ? '#f59e0b' : '#7a8ab8';

  resultsPreview.innerHTML = '';
  results.slice(0, 5).forEach(r => {
    const card = document.createElement('div');
    card.className = 'preview-card';
    card.innerHTML = `
      <div class="preview-name">${esc(r.name)}</div>
      <div class="preview-meta">
        ${r.phone ? `<span class="preview-phone">📞 ${esc(r.phone)}</span>` : `<span class="preview-no-phone">Sem telefone</span>`}
        ${r.rating ? `<span class="preview-rating">⭐ ${r.rating}</span>` : ''}
      </div>
      ${r.address ? `<div class="preview-address">${esc(r.address)}</div>` : ''}
    `;
    resultsPreview.appendChild(card);
  });
  if (results.length > 5) {
    const more = document.createElement('div');
    more.className = 'preview-more';
    more.textContent = `+ ${results.length - 5} empresas no download`;
    resultsPreview.appendChild(more);
  }
}

function showError(msg) {
  hideAll();
  errorSection.style.display = 'flex';
  errorText.textContent = msg;
}

function esc(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Search ───────────────────────────────────────────────────────────────────

btnSearch.addEventListener('click', async () => {
  const query  = queryInput.value.trim();
  const cidade = cidadeInput.value.trim();
  const target = Math.max(1, Math.min(200, parseInt(qtyInput.value) || 20));

  if (!query) { queryInput.focus(); return; }

  await chrome.storage.session.set({
    gmn: { state: 'running', found: 0, results: [], target, query: cidade ? `${query} em ${cidade}` : query }
  });

  showLoading({ found: 0, target });
  chrome.runtime.sendMessage({ type: 'START_SEARCH', query, cidade, target });
  startPolling();
});

// Enforce qty bounds on blur
qtyInput.addEventListener('blur', () => {
  const v = parseInt(qtyInput.value);
  if (isNaN(v) || v < 1)  qtyInput.value = 1;
  if (v > 200)             qtyInput.value = 200;
});

// ─── Debug Panel ─────────────────────────────────────────────────────────────

const ICONS = { info: '›', ok: '✓', warn: '!', error: '✗' };

function renderLogs(logs) {
  debugLog.innerHTML = '';
  const start = logs[0]?.t || Date.now();
  logs.forEach(entry => {
    const el = document.createElement('div');
    el.className = `debug-entry level-${entry.level}`;
    const elapsed = ((entry.t - start) / 1000).toFixed(1);
    el.innerHTML = `<span class="debug-time">+${elapsed}s</span><span class="debug-icon">${ICONS[entry.level] || '·'}</span><span class="debug-msg">${esc(entry.msg)}${entry.data ? '\n  ' + esc(entry.data) : ''}</span>`;
    debugLog.appendChild(el);
  });
  debugLog.scrollTop = debugLog.scrollHeight;
}

async function openDebug() {
  const { gmnLogs } = await chrome.storage.session.get('gmnLogs');
  renderLogs(gmnLogs || []);
  debugPanel.style.display = 'flex';
}

function closeDebug() { debugPanel.style.display = 'none'; }

debugClose?.addEventListener('click', closeDebug);
document.getElementById('btn-debug-toggle')?.addEventListener('click', openDebug);
document.getElementById('btn-debug-results')?.addEventListener('click', openDebug);
document.getElementById('btn-debug-error')?.addEventListener('click', openDebug);

// Auto-refresh logs while panel is open
setInterval(async () => {
  if (debugPanel.style.display === 'none') return;
  const { gmnLogs } = await chrome.storage.session.get('gmnLogs');
  const logs = gmnLogs || [];
  if (logs.length !== debugLog.children.length) renderLogs(logs);
}, 900);

// ─── New / Retry ──────────────────────────────────────────────────────────────

btnNew?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CANCEL' });
  chrome.storage.session.remove('gmn');
  closeDebug();
  showForm();
});

btnRetry?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CANCEL' });
  chrome.storage.session.remove('gmn');
  closeDebug();
  showForm();
});

// ─── Shared column definition ─────────────────────────────────────────────────

function buildRows(r) {
  const headers = [
    'Nome','Telefone','WhatsApp','Website','Email',
    'Endereço','CEP','Bairro','Cidade','Estado',
    'Instagram','Facebook',
    'Avaliação','Avaliações','Categoria','Preço',
    'Horário','Latitude','Longitude','URL Maps','Place ID'
  ];
  const rows = r.map(x => [
    x.name               || '',
    x.phone              || '',
    x.whatsapp           || '',
    x.website            || '',
    x.email              || '',
    x.address            || '',
    x.cep                || '',
    x.bairro             || '',
    x.cidade             || '',
    x.estado             || '',
    x.instagram          || '',
    x.facebook           || '',
    x.rating   != null   ? x.rating   : '',
    x.reviews  != null   ? x.reviews  : '',
    x.category           || '',
    x.priceLevel         || '',
    x.horasFuncionamento || '',
    x.lat      != null   ? x.lat      : '',
    x.lng      != null   ? x.lng      : '',
    x.mapsUrl            || '',
    x.place_id           || ''
  ]);
  return { headers, rows };
}

// ─── Export CSV ───────────────────────────────────────────────────────────────

btnCsv?.addEventListener('click', async () => {
  const r = window._gmnResults;
  if (!r?.length) return;

  const { headers, rows } = buildRows(r);
  const csv = '\uFEFF' + [headers, ...rows]
    .map(row => row.map(c => `"${String(c).replace(/"/g,'""')}"`).join(','))
    .join('\r\n');

  await downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }),
    `leads_${slugify(window._gmnQuery)}.csv`);
});

// ─── Export Excel ─────────────────────────────────────────────────────────────
// Generates proper OOXML .xlsx (Office Open XML) using STORE-compressed ZIP.
// No external libraries — pure JS with correct CRC32 and ZIP structure.

btnExcel?.addEventListener('click', async () => {
  const r = window._gmnResults;
  if (!r?.length) return;

  const { headers, rows } = buildRows(r);
  await downloadBlob(buildXlsx([headers, ...rows], 'Leads'),
    `leads_${slugify(window._gmnQuery)}.xlsx`);
});

// ─── XLSX Builder (OOXML + ZIP STORE) ────────────────────────────────────────

function buildXlsx(data, sheetName) {
  // CRC32 table
  const crcTable = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[i] = c;
    }
    return t;
  })();
  function crc32(bytes) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) c = (c >>> 8) ^ crcTable[(c ^ bytes[i]) & 0xFF];
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  function enc(s) { return new TextEncoder().encode(s); }
  function u16(n) { return [(n) & 0xFF, (n >> 8) & 0xFF]; }
  function u32(n) { return [(n) & 0xFF, (n >> 8) & 0xFF, (n >> 16) & 0xFF, (n >> 24) & 0xFF]; }

  function xe(s) {
    return String(s == null ? '' : s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
      .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,'');
  }

  // Build shared strings + worksheet XML
  const strs = []; const strIdx = {};
  function si(v) {
    const k = String(v == null ? '' : v);
    if (strIdx[k] === undefined) { strIdx[k] = strs.length; strs.push(k); }
    return strIdx[k];
  }

  // Column widths (chars) for the 21 standard columns
  const COL_WIDTHS = [35,16,28,30,25,45,12,20,18,8,30,30,10,12,20,8,32,12,12,40,30];
  const nCols = data[0]?.length || COL_WIDTHS.length;
  const lastColLetter = String.fromCharCode(64 + nCols);

  let wsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
    + `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">`
    + `<sheetViews><sheetView tabSelected="1" workbookViewId="0">`
    + `<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>`
    + `</sheetView></sheetViews>`
    + `<cols>`;
  for (let i = 0; i < nCols; i++) {
    const w = COL_WIDTHS[i] || 18;
    wsXml += `<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`;
  }
  wsXml += `</cols><sheetData>`;

  data.forEach((row, ri) => {
    const ht = ri === 0 ? ` ht="18" customHeight="1"` : ``;
    wsXml += `<row r="${ri+1}"${ht}>`;
    row.forEach((cell, ci) => {
      const col = String.fromCharCode(65 + ci);
      const ref = `${col}${ri+1}`;
      const s = ri === 0 ? ` s="1"` : ``;
      if (cell === null || cell === undefined || cell === '') {
        wsXml += `<c r="${ref}"${s}/>`;
      } else if (typeof cell === 'number' && isFinite(cell)) {
        wsXml += `<c r="${ref}" t="n"${s}><v>${cell}</v></c>`;
      } else {
        wsXml += `<c r="${ref}" t="s"${s}><v>${si(cell)}</v></c>`;
      }
    });
    wsXml += `</row>`;
  });
  wsXml += `</sheetData>`
    + `<autoFilter ref="A1:${lastColLetter}1"/>`
    + `</worksheet>`;

  let ssXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
    + `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"`
    + ` count="${strs.length}" uniqueCount="${strs.length}">`;
  for (const s of strs) ssXml += `<si><t xml:space="preserve">${xe(s)}</t></si>`;
  ssXml += `</sst>`;

  const files = [
    { n: '[Content_Types].xml', d: enc(
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
      +`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">`
      +`<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>`
      +`<Default Extension="xml" ContentType="application/xml"/>`
      +`<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>`
      +`<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
      +`<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>`
      +`<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>`
      +`</Types>`) },
    { n: '_rels/.rels', d: enc(
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
      +`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">`
      +`<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>`
      +`</Relationships>`) },
    { n: 'xl/workbook.xml', d: enc(
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
      +`<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"`
      +` xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">`
      +`<sheets><sheet name="${xe(sheetName)}" sheetId="1" r:id="rId1"/></sheets>`
      +`</workbook>`) },
    { n: 'xl/_rels/workbook.xml.rels', d: enc(
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
      +`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">`
      +`<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>`
      +`<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>`
      +`<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`
      +`</Relationships>`) },
    { n: 'xl/styles.xml', d: enc(
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
      +`<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">`
      +`<fonts><font><sz val="11"/></font><font><b/><sz val="11"/></font></fonts>`
      +`<fills><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>`
      +`<borders><border><left/><right/><top/><bottom/><diagonal/></border></borders>`
      +`<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>`
      +`<cellXfs>`
      +`<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>`
      +`<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>`
      +`</cellXfs></styleSheet>`) },
    { n: 'xl/sharedStrings.xml', d: enc(ssXml) },
    { n: 'xl/worksheets/sheet1.xml', d: enc(wsXml) },
  ];

  // Build ZIP with STORE (method=0, no compression)
  const localHdrs = [];
  const parts = [];
  let offset = 0;

  for (const file of files) {
    const nb = enc(file.n);
    const crc = crc32(file.d);
    const sz = file.d.length;
    const lfh = new Uint8Array([
      0x50,0x4B,0x03,0x04,  // local file header sig
      0x14,0x00,            // version needed
      0x00,0x00,            // flags
      0x00,0x00,            // method: STORE
      0x00,0x00,0x00,0x00,  // mod time/date
      ...u32(crc),          // CRC-32
      ...u32(sz),           // compressed size
      ...u32(sz),           // uncompressed size
      ...u16(nb.length),    // filename length
      0x00,0x00,            // extra length
      ...nb
    ]);
    localHdrs.push({ nb, crc, sz, offset });
    parts.push(lfh, file.d);
    offset += lfh.length + sz;
  }

  const cdParts = [];
  let cdSize = 0;
  for (let i = 0; i < files.length; i++) {
    const { nb, crc, sz, offset: lhOff } = localHdrs[i];
    const cde = new Uint8Array([
      0x50,0x4B,0x01,0x02,  // central dir sig
      0x14,0x00,0x14,0x00,  // version made/needed
      0x00,0x00,0x00,0x00,  // flags, method
      0x00,0x00,0x00,0x00,  // mod time/date
      ...u32(crc),
      ...u32(sz), ...u32(sz),
      ...u16(nb.length),
      0x00,0x00,0x00,0x00,  // extra, comment len
      0x00,0x00,0x00,0x00,  // disk, int attr
      0x00,0x00,0x00,0x00,  // ext attr
      ...u32(lhOff),
      ...nb
    ]);
    cdParts.push(cde);
    cdSize += cde.length;
  }

  const eocd = new Uint8Array([
    0x50,0x4B,0x05,0x06,
    0x00,0x00,0x00,0x00,
    ...u16(files.length), ...u16(files.length),
    ...u32(cdSize), ...u32(offset),
    0x00,0x00
  ]);

  const allParts = [...parts, ...cdParts, eocd];
  const total = allParts.reduce((s, p) => s + p.length, 0);
  const out = new Uint8Array(total);
  let pos = 0;
  for (const p of allParts) { out.set(p, pos); pos += p.length; }

  return new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function downloadBlob(blob, filename) {
  // Use FileReader to convert blob → data URL, then chrome.downloads (MV3 safe)
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
  try {
    await chrome.downloads.download({ url: dataUrl, filename, saveAs: false });
  } catch (e) {
    // Fallback: anchor click
    const a = Object.assign(document.createElement('a'), { href: dataUrl, download: filename });
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

function slugify(str) {
  return (str || 'leads').toLowerCase()
    .replace(/[àáâãä]/g,'a').replace(/[èéêë]/g,'e').replace(/[ìíîï]/g,'i')
    .replace(/[òóôõö]/g,'o').replace(/[ùúûü]/g,'u').replace(/ç/g,'c')
    .replace(/[^a-z0-9]/g,'_').replace(/_+/g,'_').slice(0,40);
}

// ─── Init ─────────────────────────────────────────────────────────────────────

(async function init() {
  const { gmn } = await chrome.storage.session.get('gmn');
  if (!gmn || gmn.state === 'idle') { showForm(); return; }
  if (gmn.state === 'running') { showLoading(gmn); startPolling(); return; }
  if (gmn.state === 'done')    { showResults(gmn); return; }
  if (gmn.state === 'error')   { showError(gmn.errorMessage || 'Erro'); return; }
  showForm();
})();
