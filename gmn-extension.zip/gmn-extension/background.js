/**
 * GMN Prospector v6 — Background Service Worker
 *
 * ARCHITECTURE:
 * - Opens INACTIVE tabs (active:false) → popup stays open the whole time
 * - Phase 1: scroll search results, collect place_ids from DOM
 *   → Early stop after 3 scrolls with no new places
 * - Phase 2: navigate CONCURRENCY tabs in parallel to each place detail URL
 *   → Extract phone, website, address, CEP, instagram, rating, etc. from real DOM
 * - No fetch-based parsing, no JSON-LD guessing
 */

'use strict';

const CONCURRENCY = 2; // Parallel place extraction tabs
let collectionAborted = false;

// ─── Logger ───────────────────────────────────────────────────────────────────

async function log(level, msg, data) {
  const entry = {
    t: Date.now(), level, msg,
    data: data !== undefined ? JSON.stringify(data).slice(0, 400) : undefined
  };
  const s = await chrome.storage.session.get('gmnLogs');
  const logs = s.gmnLogs || [];
  logs.push(entry);
  if (logs.length > 300) logs.splice(0, logs.length - 300);
  await chrome.storage.session.set({ gmnLogs: logs });
}

// ─── Messages ────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'START_SEARCH') {
    collectionAborted = false;
    runCollection(msg.query, msg.cidade, msg.target)
      .catch(err => setError(err.message || String(err)));
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CANCEL') {
    collectionAborted = true;
    sendResponse({ ok: true });
    return true;
  }
});

// ─── Storage ─────────────────────────────────────────────────────────────────

function setState(patch) {
  return chrome.storage.session.get('gmn').then(d =>
    chrome.storage.session.set({ gmn: { ...(d.gmn || {}), ...patch } })
  );
}

function setError(msg) {
  log('error', `ERRO: ${msg}`);
  return chrome.storage.session.set({ gmn: { state: 'error', errorMessage: msg } })
    .then(() => setBadge('!', '#ef4444'));
}

// ─── Badge ───────────────────────────────────────────────────────────────────

function setBadge(text, color) {
  chrome.action.setBadgeText({ text: String(text) });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}

// ─── Tab helpers ─────────────────────────────────────────────────────────────

function openTab(url) {
  // active: false → tab opens in background, popup stays open!
  return chrome.tabs.create({ url, active: false });
}

function closeTab(tabId) {
  return chrome.tabs.remove(tabId).catch(() => {});
}

function navigateTab(tabId, url) {
  return chrome.tabs.update(tabId, { url });
}

function waitForTabComplete(tabId, timeout = 20000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, timeout);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function injectScript(tabId, func, args = []) {
  return chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func,
    args
  }).then(res => res?.[0]?.result).catch(() => null);
}

// ─── Injected: wait for Maps search result cards ─────────────────────────────

function injected_waitForCards(timeoutMs) {
  return new Promise(resolve => {
    const end = Date.now() + timeoutMs;
    (function check() {
      if (document.querySelectorAll('[role="article"]').length > 0) return resolve(true);
      if (Date.now() > end) return resolve(false);
      setTimeout(check, 500);
    })();
  });
}

// ─── Injected: extract list cards (placeId + partial info) ───────────────────

function injected_extractListCards() {
  const seen = new Set();
  const cards = [];

  document.querySelectorAll('[role="article"]').forEach(card => {
    // Find place_id in any anchor href
    let placeId = null;
    for (const a of card.querySelectorAll('a[href]')) {
      const m1 = a.href.match(/place_id:([A-Za-z0-9_-]+)/);
      if (m1) { placeId = m1[1]; break; }
      const m2 = a.href.match(/(ChIJ[A-Za-z0-9_-]{8,50})/);
      if (m2) { placeId = m2[1]; break; }
    }
    // Fallback: scan innerHTML
    if (!placeId) {
      const m = card.innerHTML.match(/(ChIJ[A-Za-z0-9_-]{8,50})/);
      if (m) placeId = m[1];
    }
    if (!placeId || seen.has(placeId)) return;
    seen.add(placeId);

    const nameEl = card.querySelector('[class*="fontHeadlineSmall"], .qBF1Pd, h3, [aria-label]');
    const name = nameEl?.textContent?.trim() || card.getAttribute('aria-label') || '';

    const rEl = card.querySelector('[aria-label*="stars"], [aria-label*="estrelas"]');
    const rm = (rEl?.getAttribute('aria-label') || '').match(/(\d[.,]\d)/);
    const rating = rm ? parseFloat(rm[1].replace(',', '.')) : null;

    cards.push({ placeId, name, rating });
  });
  return cards;
}

// ─── Injected: scroll the results feed ───────────────────────────────────────

function injected_scrollPanel() {
  const feed = document.querySelector('[role="feed"]');
  if (feed) { feed.scrollBy(0, 900); return true; }
  const divs = Array.from(document.querySelectorAll('div')).filter(el => {
    const s = window.getComputedStyle(el);
    return (s.overflowY === 'scroll' || s.overflowY === 'auto') &&
      el.scrollHeight > el.clientHeight + 100 && el.clientHeight > 200;
  });
  if (divs.length) {
    divs.sort((a, b) => b.scrollHeight - a.scrollHeight)[0].scrollBy(0, 900);
    return true;
  }
  return false;
}

// ─── Injected: wait for place detail panel ───────────────────────────────────

function injected_waitForPlacePanel(timeoutMs) {
  return new Promise(resolve => {
    const end = Date.now() + timeoutMs;
    (function check() {
      if (document.querySelector('[data-item-id^="phone:tel:"]')) return resolve('phone');
      if (document.querySelector('a[data-item-id="authority"]'))  return resolve('website');
      if (document.querySelector('h1.DUwDvf, h1[class*="DUwDvf"]')) return resolve('h1');
      if (document.querySelector('[data-item-id="address"]'))     return resolve('address');
      if (Date.now() > end) return resolve(null);
      setTimeout(check, 400);
    })();
  });
}

// ─── Injected: extract full place details from rendered Maps DOM ───────────────

function injected_extractPlaceDetails() {
  // Name
  const name = document.querySelector('h1.DUwDvf, h1[class*="DUwDvf"]')?.textContent?.trim()
             || document.querySelector('h1')?.textContent?.trim()
             || null;

  // Phone — Google Maps encodes it in data-item-id="phone:tel:+55..."
  const phoneEl = document.querySelector('[data-item-id^="phone:tel:"]');
  const phone = phoneEl?.dataset?.itemId?.replace('phone:tel:', '') || null;

  // WhatsApp — look for wa.me or api.whatsapp.com links
  let whatsapp = null;
  try {
    for (const a of document.querySelectorAll('a[href*="wa.me"], a[href*="whatsapp.com"]')) {
      const m = a.href.match(/wa\.me\/(\d+)/) || a.href.match(/phone=(\d+)/);
      if (m) { whatsapp = `https://wa.me/${m[1]}`; break; }
    }
    // Fallback: derive WhatsApp from phone (handles +55..., 55..., 0XX..., and raw XX...)
    if (!whatsapp && phone) {
      let digits = phone.replace(/\D/g, '');
      // Remove leading 0 (local format: 011 XXXX-XXXX)
      if (digits.startsWith('0')) digits = digits.slice(1);
      // Add country code if missing
      if (!digits.startsWith('55') && digits.length >= 10) digits = '55' + digits;
      // Valid: 55 + DDD(2) + number(8-9) = 12-13 digits
      if (digits.startsWith('55') && digits.length >= 12 && digits.length <= 13) {
        whatsapp = `https://wa.me/${digits}`;
      }
    }
  } catch (_) {}

  // Website — anchor with data-item-id="authority"
  const siteEl = document.querySelector('a[data-item-id="authority"]');
  let website = siteEl?.href || null;
  if (website && (website.includes('google.com') || website.includes('goo.gl') || website.includes('maps.app'))) {
    website = null;
  }

  // Email — mailto: links in the page
  let email = null;
  try {
    const mailEl = document.querySelector('a[href^="mailto:"]');
    if (mailEl) email = mailEl.href.replace('mailto:', '').split('?')[0].trim();
  } catch (_) {}

  // Address (full text — usually contains CEP in Brazil)
  const addrEl = document.querySelector(
    '[data-item-id="address"], [data-tooltip="Copy address"], [aria-label*="Address"], button[aria-label*="ndereço"]'
  );
  const address = addrEl?.querySelector('.Io6YTe, .rogA2c, [class*="fontBodyMedium"]')?.textContent?.trim()
               || addrEl?.textContent?.trim()?.split('\n')[0]?.trim()
               || null;

  // CEP — extracted from address string (Brazilian format: XXXXX-XXX)
  let cep = null;
  if (address) {
    const cm = address.match(/\d{5}-\d{3}/);
    if (cm) cep = cm[0];
  }

  // Neighborhood + City + State — parse from address
  let bairro = null, cidade = null, estado = null;
  if (address) {
    // Brazilian address pattern: "Street, number - Bairro, Cidade - ST, XXXXX-XXX, Brazil"
    const parts = address.split(/[-,]/).map(s => s.trim()).filter(Boolean);
    // Try to find state abbreviation (2 uppercase letters at end of city part)
    const stateMatch = address.match(/,\s*([A-Z]{2})\s*(?:,|\d{5})/);
    if (stateMatch) estado = stateMatch[1];
    // City is usually before state
    const cityMatch = address.match(/,\s*([^,\-]+?)\s*-\s*[A-Z]{2}/);
    if (cityMatch) cidade = cityMatch[1].trim();
    // Bairro is usually before city (3rd segment)
    if (parts.length >= 3) bairro = parts[parts.length - (estado ? 3 : 2)] || null;
  }

  // Instagram — look for instagram.com link anywhere on the page
  let instagram = null;
  try {
    for (const a of document.querySelectorAll('a[href*="instagram.com"]')) {
      const m = a.href.match(/instagram\.com\/([\w.]+)\/?/);
      if (m && m[1] !== 'p' && m[1] !== 'explore' && m[1] !== 'reel' && m[1] !== 'stories' && !m[1].startsWith('_')) {
        instagram = `https://www.instagram.com/${m[1]}/`;
        break;
      }
    }
  } catch (_) {}

  // Facebook — look for facebook.com links
  let facebook = null;
  try {
    for (const a of document.querySelectorAll('a[href*="facebook.com"]')) {
      if (!a.href.includes('sharer') && !a.href.includes('dialog')) {
        facebook = a.href.split('?')[0]; break;
      }
    }
  } catch (_) {}

  // Rating + reviews
  let rating = null, reviews = null;
  const rBlock = document.querySelector('.F7nice, [class*="F7nice"]');
  if (rBlock) {
    const rText = rBlock.querySelector('[aria-hidden="true"]')?.textContent?.trim();
    if (rText) rating = parseFloat(rText.replace(',', '.'));
    const revText = rBlock.querySelector('button span, [aria-label*="review"] span')
                  ?.textContent?.replace(/[^0-9]/g, '');
    if (revText) reviews = parseInt(revText) || null;
  }
  if (!rating) {
    const rl = document.querySelector('[aria-label*="stars"], [aria-label*="estrelas"]');
    const m = rl?.getAttribute('aria-label')?.match(/(\d[.,]\d)/);
    if (m) rating = parseFloat(m[1].replace(',', '.'));
  }

  // Category
  const category = document.querySelector('.DkEaL, button[jsaction*="category"] .Io6YTe')
                 ?.textContent?.trim() || null;

  // Price level ($, $$, $$$, $$$$)
  let priceLevel = null;
  try {
    const priceEl = document.querySelector('[aria-label*="rice level"], [aria-label*="reço"]');
    const priceM = priceEl?.getAttribute('aria-label')?.match(/(\$+)/);
    if (priceM) priceLevel = priceM[1];
    if (!priceLevel) {
      // Try the price text rendered in the header area
      const pText = document.querySelector('.mgr77e')?.textContent?.trim();
      if (pText && /^\$+$/.test(pText)) priceLevel = pText;
    }
  } catch (_) {}

  // Opening hours — grab open/closed status + hours from Maps detail panel
  let horasFuncionamento = null;
  try {
    // Try 1: data-item-id starting with "oh:" (business hours section)
    const ohEl = document.querySelector('[data-item-id^="oh:"]');
    if (ohEl) {
      // Look for text inside — open/closed + time
      const spans = ohEl.querySelectorAll('span, div');
      for (const s of spans) {
        const t = s.textContent?.trim();
        if (t && t.length > 3 && t.length < 80 && /\d/.test(t)) {
          horasFuncionamento = t; break;
        }
      }
      if (!horasFuncionamento) horasFuncionamento = ohEl.textContent?.trim()?.split('\n')[0] || null;
    }
    // Try 2: aria-expanded button for hours (the "Open/Closed · closes at X" button)
    if (!horasFuncionamento) {
      const btns = document.querySelectorAll('button[aria-expanded]');
      for (const btn of btns) {
        const t = btn.textContent?.trim();
        if (t && (t.includes('Aberto') || t.includes('Fechado') || t.includes('Open') || t.includes('Closed') || /\d{1,2}:\d{2}/.test(t))) {
          horasFuncionamento = t.split('\n')[0].trim().slice(0, 80); break;
        }
      }
    }
    // Try 3: aria-label with time pattern on any button
    if (!horasFuncionamento) {
      const allBtns = document.querySelectorAll('button[aria-label]');
      for (const b of allBtns) {
        const lbl = b.getAttribute('aria-label') || '';
        if (/\d{1,2}[h:]\d{2}/.test(lbl) || lbl.includes('Aberto') || lbl.includes('Fechado')) {
          horasFuncionamento = lbl.slice(0, 80); break;
        }
      }
    }
    // Try 4: spans/divs with open/closed text pattern
    if (!horasFuncionamento) {
      const all = document.querySelectorAll('span, div');
      for (const el of all) {
        const t = el.childElementCount === 0 ? el.textContent?.trim() : null;
        if (t && (t.startsWith('Aberto') || t.startsWith('Fechado') || t.startsWith('Open') || t.startsWith('Closed')) && t.length < 100) {
          horasFuncionamento = t; break;
        }
      }
    }
  } catch (_) {}

  // Coordinates from page URL
  const cm2 = location.href.match(/@(-?\d+\.\d{4,}),(-?\d+\.\d{4,})/);
  const lat = cm2 ? parseFloat(cm2[1]) : null;
  const lng = cm2 ? parseFloat(cm2[2]) : null;

  // Google Maps URL for the place
  const mapsUrl = location.href.split('?')[0] || null;

  return {
    name, phone, whatsapp, website, email,
    address, cep, bairro, cidade, estado,
    instagram, facebook,
    rating, reviews, category, priceLevel,
    horasFuncionamento, lat, lng, mapsUrl
  };
}

// ─── Extract one place from a given worker tab ────────────────────────────────

async function extractPlaceInTab(tabId, placeId, partial, idx, total) {
  const label = partial.name?.slice(0, 35) || placeId.slice(0, 14);
  await log('info', `[${idx}/${total}] ${label}`);

  await navigateTab(tabId, `https://www.google.com/maps/search/?q=place_id:${placeId}&hl=pt-BR`);
  await waitForTabComplete(tabId, 15000);
  await sleep(2000);

  const panelReady = await injectScript(tabId, injected_waitForPlacePanel, [10000]);

  if (panelReady) {
    const details = await injectScript(tabId, injected_extractPlaceDetails);
    if (details && (details.name || partial.name)) {
      const record = {
        place_id:           placeId,
        name:               details.name              || partial.name   || null,
        phone:              details.phone             || null,
        whatsapp:           details.whatsapp          || null,
        website:            details.website           || null,
        email:              details.email             || null,
        address:            details.address           || null,
        cep:                details.cep               || null,
        bairro:             details.bairro            || null,
        cidade:             details.cidade            || null,
        estado:             details.estado            || null,
        instagram:          details.instagram         || null,
        facebook:           details.facebook          || null,
        rating:             details.rating            ?? partial.rating ?? null,
        reviews:            details.reviews           || null,
        category:           details.category          || null,
        priceLevel:         details.priceLevel        || null,
        horasFuncionamento: details.horasFuncionamento|| null,
        lat:                details.lat               || null,
        lng:                details.lng               || null,
        mapsUrl:            details.mapsUrl           || null,
      };
      const tel  = record.phone    ? '✓' : '✗';
      const site = record.website  ? '✓' : '✗';
      const wpp  = record.whatsapp ? ' wpp=✓' : '';
      const ig   = record.instagram? ' ig=✓'  : '';
      await log(
        record.phone || record.website ? 'ok' : 'warn',
        `${(record.name || '').slice(0, 30)} | tel=${tel} site=${site}${wpp}${ig}`
      );
      return record;
    }
  }

  // Timeout — use partial data from list
  await log('warn', `Timeout: "${label}" — dados parciais`);
  if (partial.name) {
    return {
      place_id: placeId,
      name: partial.name,
      phone: null, whatsapp: null, website: null, email: null,
      address: null, cep: null, bairro: null, cidade: null, estado: null,
      instagram: null, facebook: null,
      rating: partial.rating || null, reviews: null,
      category: null, priceLevel: null, horasFuncionamento: null,
      lat: null, lng: null, mapsUrl: null,
    };
  }
  return null;
}

// ─── Main collection ──────────────────────────────────────────────────────────

async function runCollection(query, cidade, target) {
  const searchQuery = cidade ? `${query} em ${cidade}` : query;
  const searchUrl   = `https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`;

  await chrome.storage.session.set({ gmnLogs: [] });
  await log('info', `Iniciando: "${searchQuery}"`, { target });
  await chrome.storage.session.set({
    gmn: { state: 'running', query: searchQuery, target, found: 0, results: [], startedAt: Date.now() }
  });
  setBadge('...', '#2D52EF');

  // ── Phase 1: Open search tab INACTIVE ────────────────────────────────────
  await log('info', 'Abrindo Google Maps em segundo plano (popup continua aberto)...');
  const searchTab = await openTab(searchUrl);
  await waitForTabComplete(searchTab.id, 25000);
  await sleep(3500);

  const hasCards = await injectScript(searchTab.id, injected_waitForCards, [20000]);
  if (!hasCards && !collectionAborted) {
    await closeTab(searchTab.id);
    return setError('Google Maps não carregou resultados. Verifique conexão e tente novamente.');
  }
  if (collectionAborted) { await closeTab(searchTab.id); return; }
  await log('ok', 'Resultados do Maps carregados ✓');

  // ── Phase 2: Scroll and collect place_ids ────────────────────────────────
  const seen      = new Set();
  const placeIds  = [];
  const partial   = {};
  const maxScrolls = Math.ceil(target / 5) + 14; // generous limit
  let noNewCount  = 0;

  await log('info', `Coletando places (meta: ${target}, até ${maxScrolls} scrolls)...`);

  for (let s = 0; placeIds.length < target && s < maxScrolls && !collectionAborted; s++) {
    const prevLen = placeIds.length;
    const cards = await injectScript(searchTab.id, injected_extractListCards) || [];

    for (const c of cards) {
      if (c.placeId && !seen.has(c.placeId)) {
        seen.add(c.placeId);
        placeIds.push(c.placeId);
        partial[c.placeId] = c;
      }
    }

    await log('info', `Scroll ${s + 1}: ${placeIds.length} lugares únicos`);
    if (placeIds.length >= target) break;

    if (placeIds.length === prevLen) {
      noNewCount++;
      if (noNewCount >= 3) {
        await log('info', `Sem novos resultados por 3 scrolls — encerrando coleta da lista.`);
        break;
      }
    } else {
      noNewCount = 0;
    }

    await injectScript(searchTab.id, injected_scrollPanel);
    await sleep(1400);
  }

  await closeTab(searchTab.id);
  if (collectionAborted) return;

  if (placeIds.length === 0) {
    return setError('Nenhum resultado encontrado. Tente outros termos ou cidade.');
  }

  const toProcess = placeIds.slice(0, target);
  await log('ok', `${placeIds.length} places → extraindo detalhes de ${toProcess.length} (${CONCURRENCY} paralelos)...`);

  // ── Phase 3: Parallel extraction with CONCURRENCY worker tabs ─────────────
  const results = [];

  // Create worker tabs
  const workerIds = [];
  for (let i = 0; i < CONCURRENCY; i++) {
    const t = await chrome.tabs.create({ url: 'about:blank', active: false });
    workerIds.push(t.id);
  }

  // Process in batches of CONCURRENCY
  for (let i = 0; i < toProcess.length && !collectionAborted; i += CONCURRENCY) {
    const batch = toProcess.slice(i, Math.min(i + CONCURRENCY, toProcess.length));

    const batchResults = await Promise.all(
      batch.map((placeId, bi) =>
        extractPlaceInTab(
          workerIds[bi],
          placeId,
          partial[placeId] || {},
          i + bi + 1,
          toProcess.length
        )
      )
    );

    for (const r of batchResults) {
      if (r) results.push(r);
    }

    const processed = Math.min(i + CONCURRENCY, toProcess.length);
    const pct = Math.round(processed / toProcess.length * 100);
    await setState({ found: results.length, results: [...results], progress: pct });
    setBadge(String(results.length), '#2D52EF');
  }

  // Close worker tabs
  for (const wid of workerIds) closeTab(wid);
  if (collectionAborted) return;

  const withPhone = results.filter(r => r.phone).length;
  const withSite  = results.filter(r => r.website).length;
  const withIg    = results.filter(r => r.instagram).length;
  await log('ok', `✅ ${results.length} leads | ${withPhone} tel | ${withSite} site | ${withIg} instagram`);

  await chrome.storage.session.set({
    gmn: { state: 'done', query: searchQuery, target, found: results.length, results }
  });
  setBadge('✓', '#22c55e');
}
