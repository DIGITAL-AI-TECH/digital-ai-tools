/**
 * GMN Prospector v4 — Background Service Worker
 *
 * ARCHITECTURE:
 * - Opens ONE search tab to collect place_ids from Maps DOM
 * - All enrichment happens via fetch() INJECTED into that same tab
 *   → same-origin request = user's Google session cookies included
 *   → NO additional tabs opened per place
 * - Popup stays accessible the entire time
 */

'use strict';

let collectionAborted = false;

// ─── Logger ───────────────────────────────────────────────────────────────────

async function log(level, msg, data) {
  const entry = {
    t: Date.now(),
    level,
    msg,
    data: data !== undefined ? JSON.stringify(data).slice(0, 400) : undefined
  };
  const s = await chrome.storage.session.get('gmnLogs');
  const logs = s.gmnLogs || [];
  logs.push(entry);
  if (logs.length > 300) logs.splice(0, logs.length - 300);
  await chrome.storage.session.set({ gmnLogs: logs });
}

// ─── Messages ────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'START_SEARCH') {
    collectionAborted = false;
    runCollection(msg.query, msg.cidade, msg.target)
      .catch(err => setError(err.message || String(err)));
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CANCEL') {
    collectionAborted = true;
    sendResponse({ ok: true });
    return true;
  }
});

// ─── Storage ─────────────────────────────────────────────────────────────────

function setState(patch) {
  return chrome.storage.session.get('gmn').then(d => {
    return chrome.storage.session.set({ gmn: { ...(d.gmn || {}), ...patch } });
  });
}

function setError(msg) {
  log('error', `ERRO: ${msg}`);
  return chrome.storage.session.set({ gmn: { state: 'error', errorMessage: msg } })
    .then(() => setBadge('!', '#ef4444'));
}

// ─── Badge ───────────────────────────────────────────────────────────────────

function setBadge(text, color) {
  chrome.action.setBadgeText({ text: String(text) });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}

// ─── Tab helpers ─────────────────────────────────────────────────────────────

function openTab(url, active = true) {
  return chrome.tabs.create({ url, active });
}

function closeTab(tabId) {
  return chrome.tabs.remove(tabId).catch(() => {});
}

function waitForTabComplete(tabId, timeout = 25000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, timeout);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function injectScript(tabId, func, args = []) {
  return chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func,
    args
  }).then(res => res?.[0]?.result).catch(() => null);
}

// ─── Injected: wait for Maps cards ───────────────────────────────────────────

function injected_waitForCards(timeoutMs) {
  return new Promise(resolve => {
    const deadline = Date.now() + timeoutMs;
    (function check() {
      if (document.querySelectorAll('[role="article"]').length > 0) return resolve(true);
      if (Date.now() > deadline) return resolve(false);
      setTimeout(check, 500);
    })();
  });
}

// ─── Injected: extract place_ids from search results page ────────────────────

function injected_extractPlaceIds() {
  const ids = new Set();

  // From anchor hrefs containing place_id:
  document.querySelectorAll('a[href*="place_id"]').forEach(a => {
    const m = a.href.match(/place_id:([A-Za-z0-9_\-]+)/);
    if (m) ids.add(m[1]);
  });

  // From anchor hrefs /maps/place/Name/@lat,lng/data= (no place_id, but has CID)
  // Also scan full page HTML for ChIJ patterns:
  const html = document.documentElement.innerHTML;
  let m;
  const re = /ChIJ[A-Za-z0-9_\-]{8,50}/g;
  while ((m = re.exec(html)) !== null) ids.add(m[0]);

  return [...ids];
}

// ─── Injected: scroll the results panel ──────────────────────────────────────

function injected_scrollPanel() {
  const feed = document.querySelector('[role="feed"]');
  if (feed) { feed.scrollBy(0, 900); return true; }
  const divs = Array.from(document.querySelectorAll('div')).filter(el => {
    const s = window.getComputedStyle(el);
    return (s.overflowY === 'scroll' || s.overflowY === 'auto') &&
      el.scrollHeight > el.clientHeight + 100 && el.clientHeight > 200;
  });
  if (divs.length) {
    divs.sort((a, b) => b.scrollHeight - a.scrollHeight)[0].scrollBy(0, 900);
    return true;
  }
  return false;
}

// ─── Injected: extract DOM cards (partial fallback) ──────────────────────────

function injected_extractDomCards() {
  const results = [];
  document.querySelectorAll('[role="article"]').forEach(card => {
    const nameEl = card.querySelector('[class*="fontHeadlineSmall"], h3, [aria-label]');
    const name = nameEl?.textContent?.trim() || card.getAttribute('aria-label') || '';
    if (!name) return;

    const ratingEl = card.querySelector('[aria-label*="stars"], [aria-label*="estrelas"]');
    const ratingText = ratingEl?.getAttribute('aria-label') || '';
    const ratingM = ratingText.match(/(\d[\.,]\d)/);
    const rating = ratingM ? parseFloat(ratingM[1].replace(',', '.')) : null;

    const spans = Array.from(card.querySelectorAll('span,div'))
      .map(el => el.textContent.trim()).filter(t => t.length > 3 && t.length < 200);
    const address = spans.find(t => t.match(/,\s*[A-Z]{2}$/) || t.match(/R\.|Av\.|Rua |Alameda/)) || null;

    const anchor = card.querySelector('a[href*="place_id"]');
    const pidM = anchor?.href?.match(/place_id:([A-Za-z0-9_\-]+)/);
    const place_id = pidM ? pidM[1] : null;

    results.push({ name, rating, address, place_id, source: 'dom' });
  });
  return results;
}

// ─── Injected: fetch place details via same-origin request ───────────────────
// Runs inside the Maps tab → user's session cookies are sent automatically.
// Parses JSON-LD structured data (Google embeds this for SEO).

function injected_fetchPlaceDetails(placeId) {
  return fetch(`/maps/place/?q=place_id:${placeId}&hl=pt-BR`, {
    credentials: 'include',
    headers: { 'Accept': 'text/html,application/xhtml+xml' }
  })
  .then(r => {
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.text();
  })
  .then(html => {
    // ── Strategy 1: JSON-LD structured data (most reliable) ──
    const ldMatches = [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)];
    for (const lm of ldMatches) {
      try {
        const ld = JSON.parse(lm[1]);
        // May be an array or single object
        const items = Array.isArray(ld) ? ld : [ld];
        for (const item of items) {
          if (!item.name) continue;
          const geo  = item.geo || {};
          const addr = item.address || {};
          const rat  = item.aggregateRating || {};

          const addrParts = [
            addr.streetAddress,
            addr.addressLocality,
            addr.addressRegion,
            addr.postalCode
          ].filter(Boolean);

          let website = item.url || item.sameAs || null;
          if (website && (website.includes('google') || website.includes('maps.app'))) website = null;

          let phone = item.telephone || null;
          if (Array.isArray(phone)) phone = phone[0] || null;

          const lat = geo.latitude  != null ? parseFloat(geo.latitude)  : null;
          const lng = geo.longitude != null ? parseFloat(geo.longitude) : null;

          const types = item['@type'];
          const category = Array.isArray(types) ? types.filter(t => t !== 'Place').join(', ') : (types || null);

          return {
            name:     item.name,
            phone:    phone,
            website:  website,
            address:  addrParts.length ? addrParts.join(', ') : null,
            rating:   rat.ratingValue  ? parseFloat(String(rat.ratingValue).replace(',','.'))  : null,
            reviews:  rat.reviewCount  ? parseInt(String(rat.reviewCount).replace(/\D/g,''))   : null,
            lat, lng,
            category,
            source:   'json-ld'
          };
        }
      } catch(e) { /* try next */ }
    }

    // ── Strategy 2: Open Graph + regex fallback ──
    const ogTitle   = html.match(/property="og:title"\s+content="([^"]+)"/)?.[1]?.replace(' - Google Maps','').trim();
    const h1Title   = html.match(/<h1[^>]*>([^<]+)<\/h1>/)?.[1]?.trim();

    // Phone patterns (BR)
    const phonePat  = /\+55\s*\(?(\d{2})\)?\s*\d{4,5}[\-\s]\d{4}|\(\d{2}\)\s*\d{4,5}[-\s]\d{4}/;
    const phoneM    = html.match(phonePat);
    let phone       = phoneM ? phoneM[0].trim() : null;

    // Website
    const urlPat    = /"(https?:\/\/(?!(?:www\.)?(?:google|goo\.gl|googleapis|schema\.org|facebook|twitter|instagram|linkedin))[^"\\]{5,200})"/g;
    let website     = null;
    let um;
    while ((um = urlPat.exec(html)) !== null) {
      const u = um[1];
      if (!u.includes('google') && !u.includes('goo.gl') && !u.endsWith('.svg') && !u.endsWith('.png')) {
        website = u;
        break;
      }
    }

    // Coordinates from URL pattern /@lat,lng/
    const coordM    = html.match(/@(-?\d{1,3}\.\d{4,}),(-?\d{1,3}\.\d{4,})/);
    const lat       = coordM ? parseFloat(coordM[1]) : null;
    const lng       = coordM ? parseFloat(coordM[2]) : null;

    return {
      name:    ogTitle || h1Title || null,
      phone,
      website,
      address: null,
      rating:  null,
      reviews: null,
      lat, lng,
      category: null,
      source:  'html-regex'
    };
  })
  .catch(e => ({ error: e.message, name: null }));
}

// ─── Main collection ──────────────────────────────────────────────────────────

async function runCollection(query, cidade, target) {
  const searchQuery = cidade ? `${query} em ${cidade}` : query;
  const searchUrl   = `https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`;

  await chrome.storage.session.set({ gmnLogs: [] });
  await log('info', `Iniciando coleta: "${searchQuery}"`, { target });

  await chrome.storage.session.set({
    gmn: {
      state: 'running',
      query: searchQuery,
      target,
      found: 0,
      results: [],
      startedAt: Date.now()
    }
  });
  setBadge('...', '#2D52EF');

  // ── 1. Open search tab ────────────────────────────────────────────────────
  await log('info', 'Abrindo Google Maps...');
  const searchTab = await openTab(searchUrl, true);
  await waitForTabComplete(searchTab.id, 25000);
  await sleep(2500);
  await log('info', `Tab #${searchTab.id} carregada. Aguardando cards...`);

  const hasCards = await injectScript(searchTab.id, injected_waitForCards, [18000]);
  if (!hasCards && !collectionAborted) {
    await closeTab(searchTab.id);
    return setError('Google Maps não carregou resultados. Tente novamente.');
  }
  await log('ok', 'Cards detectados ✓');
  if (collectionAborted) { await closeTab(searchTab.id); return; }

  // ── 2. Collect place_ids via scroll ──────────────────────────────────────
  const allIds = new Set();
  const maxScrolls = Math.ceil(target / 4) + 6;
  await log('info', `Coletando place_ids (meta: ${target}, max scrolls: ${maxScrolls})...`);

  for (let scroll = 0; allIds.size < target && scroll < maxScrolls && !collectionAborted; scroll++) {
    const ids = await injectScript(searchTab.id, injected_extractPlaceIds);
    if (ids) ids.forEach(id => allIds.add(id));
    await log('info', `Scroll ${scroll + 1}: ${allIds.size} place_ids únicos`);
    if (allIds.size >= target) break;
    await injectScript(searchTab.id, injected_scrollPanel);
    await sleep(1400);
  }

  const domCards = await injectScript(searchTab.id, injected_extractDomCards) || [];
  domCards.forEach(c => { if (c.place_id) allIds.add(c.place_id); });

  await log('ok', `Total: ${allIds.size} place_ids | ${domCards.length} DOM cards`);

  if (collectionAborted) { await closeTab(searchTab.id); return; }

  const placeIds = [...allIds].slice(0, target);

  if (placeIds.length === 0) {
    if (domCards.length > 0) {
      await log('warn', `Sem place_ids via links — usando ${domCards.length} DOM cards`);
      await chrome.storage.session.set({
        gmn: { state: 'done', query: searchQuery, target, found: domCards.length, results: domCards }
      });
      setBadge('✓', '#2D52EF');
      await closeTab(searchTab.id);
      return;
    }
    await closeTab(searchTab.id);
    return setError('Nenhuma empresa encontrada. Tente outro termo ou cidade.');
  }

  // ── 3. Enrich via fetch() injected in the search tab (NO new tabs!) ───────
  await log('info', `Enriquecendo ${placeIds.length} lugares via fetch (sem abrir novas abas)...`);

  const results = [];
  const domCardMap = {};
  domCards.forEach(c => { if (c.place_id) domCardMap[c.place_id] = c; });

  const BATCH = 4; // 4 concurrent fetches from within the Maps tab

  for (let i = 0; i < placeIds.length && !collectionAborted; i += BATCH) {
    const batch = placeIds.slice(i, i + BATCH);

    const batchData = await Promise.all(
      batch.map(id => injectScript(searchTab.id, injected_fetchPlaceDetails, [id]))
    );

    for (let j = 0; j < batch.length; j++) {
      const placeId = batch[j];
      const data = batchData[j];
      const dom  = domCardMap[placeId];

      if (data && data.name) {
        const hasPhone = !!(data.phone);
        const hasWeb   = !!(data.website);
        await log(
          hasPhone || hasWeb ? 'ok' : 'warn',
          `${data.name.slice(0,38)} | tel=${hasPhone?'✓':'✗'} site=${hasWeb?'✓':'✗'} [${data.source}]`
        );
        results.push({
          place_id: placeId,
          name:     data.name,
          phone:    data.phone    || dom?.phone    || null,
          website:  data.website  || null,
          address:  data.address  || dom?.address  || null,
          rating:   data.rating   || dom?.rating   || null,
          reviews:  data.reviews  || null,
          lat:      data.lat      || null,
          lng:      data.lng      || null,
          category: data.category || null,
          source:   data.source   || 'enriched'
        });
      } else if (dom) {
        await log('warn', `${dom.name?.slice(0,38)} — sem JSON-LD, usando DOM card`);
        results.push({
          place_id: placeId,
          name: dom.name, phone: null, website: null,
          address: dom.address || null, rating: dom.rating || null,
          reviews: null, lat: null, lng: null, category: null,
          source: 'dom-partial'
        });
      } else if (data?.error) {
        await log('error', `Erro fetch ${placeId.slice(0,14)}: ${data.error}`);
      }
    }

    const pct = Math.round((i + batch.length) / placeIds.length * 100);
    await setState({ found: results.length, results: [...results], progress: pct });
    setBadge(String(results.length), '#2D52EF');
  }

  await closeTab(searchTab.id);
  await log('info', 'Aba de busca fechada');

  if (collectionAborted) return;

  const withPhone = results.filter(r => r.phone).length;
  const withSite  = results.filter(r => r.website).length;
  await log('ok', `✅ Concluído! ${results.length} leads | ${withPhone} com telefone | ${withSite} com site`);

  await chrome.storage.session.set({
    gmn: { state: 'done', query: searchQuery, target, found: results.length, results, source: 'enriched' }
  });
  setBadge('✓', '#22c55e');
}
